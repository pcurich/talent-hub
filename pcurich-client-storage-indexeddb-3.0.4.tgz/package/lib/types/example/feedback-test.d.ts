import { FeedbackEntity } from '../indexeddb/entities/feedback-entity';
import { FeedbackService } from '../indexeddb/services/feedback-service';
export declare function createFeedbackService(): Promise<FeedbackService>;
export declare function exampleCreateFeedback(): Promise<FeedbackEntity>;
export declare function exampleFindBySquad(): Promise<FeedbackEntity[]>;
export declare function exampleFindByDateRange(): Promise<FeedbackEntity[]>;
export declare function exampleFindPendingActions(): Promise<FeedbackEntity[]>;
export declare function exampleMultipleCriteria(): Promise<FeedbackEntity[]>;
