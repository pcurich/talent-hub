import { BaseEntity } from "./base-entity";
/**
 * Tipos de feedback posibles
 */
export type FeedbackType = 'Positivo' | 'Constructivo' | 'Negativo' | string;
/**
 * Estados posibles del accionable
 */
export type ActionableStatus = 'Pendiente' | 'En Progreso' | 'Completado' | 'Cancelado' | string;
/**
 * Responsable del plan de acción
 */
export type ActionResponsible = 'CL' | 'FP' | 'PO' | 'AC' | 'OTHER' | string;
/**
 * Seniority del team member
 */
export type Seniority = 'Junior' | 'Semi-Senior' | 'Senior' | 'Lead' | 'Architect' | string;
/**
 * Tipo de empresa
 */
export type CompanyType = 'BCP' | 'Proveedor' | string;
/**
 * Calificación general
 */
export type GeneralRating = 'Excelente' | 'Muy Bueno' | 'Bueno' | 'Regular' | 'Necesita Mejorar' | string;
/**
 * Nivel de desempeño
 */
export type PerformanceLevel = 'Supera Expectativas' | 'Cumple Expectativas' | 'Por Debajo de Expectativas' | string;
/**
 * Detalles del feedback estructurado (SBI - Situation, Behavior, Impact)
 */
export interface FeedbackDetails {
    situation: string;
    behavior: string;
    impact: string;
}
/**
 * Plan de acción asociado al feedback
 */
export interface ActionPlan {
    actionable: string;
    responsible: ActionResponsible;
    commitmentDate: Date | string;
    status: ActionableStatus;
    details: string;
}
/**
 * Entidad para gestionar evaluaciones y feedback de team members
 */
export declare class FeedbackEntity extends BaseEntity {
    number: number;
    registration: string;
    teamMember: string;
    company: CompanyType;
    seniority: Seniority;
    squad: string;
    productOwner: string;
    focalPoint: string;
    poclacDate: Date | string;
    feedbackProvider: string;
    generalRating: GeneralRating;
    performanceWhat: PerformanceLevel;
    performanceHow: PerformanceLevel;
    performanceAchievements: PerformanceLevel;
    performanceDetails: string;
    feedbackType: FeedbackType;
    feedbackDetails: FeedbackDetails;
    userExpectations: string;
    actionPlan: ActionPlan[];
    /**
     * Crea una nueva instancia a partir de un objeto de inicialización parcial.
     */
    constructor(init?: Partial<FeedbackEntity>);
}
