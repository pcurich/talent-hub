import { BaseEntity } from "./base-entity";
export declare class HttpMockEntity extends BaseEntity {
    name: string;
    serviceCode: string;
    url: string;
    method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD' | 'OPTIONS' | 'CONNECT' | 'TRACE' | string;
    httpCodeResponseValue: number;
    delayMs: number;
    headers?: Record<string, string>;
    responseBody: string;
    /**
     * Crea una nueva instancia a partir de un objeto de inicialización parcial.
     * Se asignan valores por defecto cuando faltan propiedades en el objeto.
     */
    constructor(init?: Partial<HttpMockEntity>);
}
