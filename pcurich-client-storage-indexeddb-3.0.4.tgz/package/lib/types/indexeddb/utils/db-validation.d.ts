import { DBInitOptions } from './inspect-db-structure';
/**
 * Valida si existe una base de datos con el store especificado
 * @param config Configuración de la base de datos a validar
 * @returns true si existe la base de datos y el store[0], false en caso contrario
 */
export declare function databaseExists(config: DBInitOptions): Promise<boolean>;
