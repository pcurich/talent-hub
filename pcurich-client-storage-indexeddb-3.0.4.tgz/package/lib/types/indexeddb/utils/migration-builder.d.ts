import { Migration } from '../context/db-context';
import { DBInitOptions } from './inspect-db-structure';
/**
 * Genera una función de migración a partir de la configuración de stores.
 */
export declare function makeMigration(stores: DBInitOptions['stores']): Migration;
