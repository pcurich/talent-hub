export declare function injectHttpMockManagerFromUrl(jsRurl: string, container: HTMLElement): Promise<void>;
export declare function injectHttpMockManagerInline(container: HTMLElement): Promise<void>;
