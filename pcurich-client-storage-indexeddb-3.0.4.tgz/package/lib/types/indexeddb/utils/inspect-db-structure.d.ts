export type IndexConfig = {
    name: string;
    keyPath: string | string[];
    options?: IDBIndexParameters;
};
export type StoreConfig = {
    name: string;
    keyPath?: string;
    autoIncrement?: boolean;
    indexes?: IndexConfig[];
};
export type DBInitOptions = {
    dbName: string;
    version: number;
    stores: StoreConfig[];
};
export declare function inspectDbStructure(): Promise<DBInitOptions>;
