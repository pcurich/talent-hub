import { DbContext } from "../context/db-context";
import { HttpMockEntity } from "../entities/http-mock-entity";
import { IHttpMockService } from "./i-http-mock-service";
export declare class HttpMockService implements IHttpMockService {
    private repos;
    private defaultStore;
    private dbContext;
    constructor(dbContext: DbContext, storeName?: string, keyPath?: string);
    private getRepo;
    createMock(data: Partial<HttpMockEntity>, storeName?: string): Promise<HttpMockEntity>;
    getMockById(id: IDBValidKey, storeName?: string): Promise<HttpMockEntity | null>;
    updateMock(entity: HttpMockEntity, storeName?: string): Promise<HttpMockEntity>;
    deleteMock(id: IDBValidKey, storeName?: string): Promise<boolean>;
    getAllMocks(storeName?: string): Promise<HttpMockEntity[]>;
    private getIndexNameForKeyPathForStore;
    findByUrl(url: string, indexName?: string, expectedKeyPath?: string | string[], storeName?: string): Promise<HttpMockEntity[]>;
    findByServiceCode(serviceCode: string, indexName?: string, expectedKeyPath?: string | string[], storeName?: string): Promise<HttpMockEntity[]>;
    findByIndex(value: IDBValidKey | IDBKeyRange, indexName?: string, expectedKeyPath?: string | string[], storeName?: string): Promise<HttpMockEntity[]>;
    getResponseBodyAs<T>(id: IDBValidKey, storeName?: string): Promise<T | null>;
}
