import { FeedbackEntity } from "../entities/feedback-entity";
export interface IFeedbackService {
    createFeedback(data: Partial<FeedbackEntity>, storeName?: string): Promise<FeedbackEntity>;
    getFeedbackById(id: IDBValidKey, storeName?: string): Promise<FeedbackEntity | null>;
    updateFeedback(entity: FeedbackEntity, storeName?: string): Promise<FeedbackEntity>;
    deleteFeedback(id: IDBValidKey, storeName?: string): Promise<void>;
    getAllFeedbacks(storeName?: string): Promise<FeedbackEntity[]>;
    findByRegistration(registration: string, storeName?: string): Promise<FeedbackEntity[]>;
    findBySquad(squad: string, storeName?: string): Promise<FeedbackEntity[]>;
    findByPO(po: string, storeName?: string): Promise<FeedbackEntity[]>;
    findByFocalPoint(focalPoint: string, storeName?: string): Promise<FeedbackEntity[]>;
    findByCompany(company: string, storeName?: string): Promise<FeedbackEntity[]>;
    findBySeniority(seniority: string, storeName?: string): Promise<FeedbackEntity[]>;
    findByDateRange(startDate: Date, endDate: Date, storeName?: string): Promise<FeedbackEntity[]>;
    findByActionStatus(status: string, storeName?: string): Promise<FeedbackEntity[]>;
    findWithPendingActions(storeName?: string): Promise<FeedbackEntity[]>;
}
