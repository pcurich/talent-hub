import { DbContext } from "../context/db-context";
import { HttpMockEntity } from "../entities/http-mock-entity";
import BaseRepository from "./base-repository";
import { IRepository } from "./i-repository";
export declare class HttpMockRepository extends BaseRepository<HttpMockEntity> implements IRepository<HttpMockEntity> {
    private storeCfg?;
    constructor(db: DbContext, storeName?: string, keyPath?: string);
    private resolveIndexName;
    /**
     * Buscar codigo del servicio por un índice configurable.
     * @param value valor o keyRange para la búsqueda (ej: serviceCode o IDBKeyRange)
     * @param indexName nombre del índice (opcional — se resuelve desde la configuración)
     * @param expectedKeyPath opcional: keyPath esperado para el índice (ej: 'serviceCode' o ['a','b'])
     */
    findByIndex(value: IDBValidKey | IDBKeyRange, indexName?: string, expectedKeyPath?: string | string[]): Promise<HttpMockEntity[]>;
}
