import { DbContext } from "../context/db-context";
import { FeedbackEntity } from "../entities/feedback-entity";
import BaseRepository from "./base-repository";
import { IRepository } from "./i-repository";
export declare class FeedbackRepository extends BaseRepository<FeedbackEntity> implements IRepository<FeedbackEntity> {
    private storeCfg?;
    constructor(db: DbContext, storeName?: string, keyPath?: string);
    private resolveIndexName;
    /**
     * Busca feedback por matrícula del team member
     */
    findByRegistration(registration: string, indexName?: string): Promise<FeedbackEntity[]>;
    /**
     * Busca feedback por squad
     */
    findBySquad(squad: string, indexName?: string): Promise<FeedbackEntity[]>;
    /**
     * Busca feedback por Product Owner
     */
    findByProductOwner(productOwner: string, indexName?: string): Promise<FeedbackEntity[]>;
    /**
     * Busca feedback por Focal Point
     */
    findByFocalPoint(focalPoint: string, indexName?: string): Promise<FeedbackEntity[]>;
    /**
     * Busca feedback por empresa
     */
    findByCompany(company: string, indexName?: string): Promise<FeedbackEntity[]>;
    /**
     * Busca feedback por seniority
     */
    findBySeniority(seniority: string, indexName?: string): Promise<FeedbackEntity[]>;
    /**
     * Busca feedback por rango de fechas de POCLAC
     */
    findByDateRange(startDate: Date, endDate: Date): Promise<FeedbackEntity[]>;
    /**
     * Busca feedback con accionables que tengan un estado específico
     */
    findByActionStatus(status: string): Promise<FeedbackEntity[]>;
    /**
    * Buscar codigo del servicio por un índice configurable.
    * @param value valor o keyRange para la búsqueda (ej: serviceCode o IDBKeyRange)
    * @param indexName nombre del índice (opcional — se resuelve desde la configuración)
    * @param expectedKeyPath opcional: keyPath esperado para el índice (ej: 'serviceCode' o ['a','b'])
    */
    findByIndex(value: IDBValidKey | IDBKeyRange, indexName?: string, expectedKeyPath?: string | string[]): Promise<FeedbackEntity[]>;
}
