import { IDbContext } from "../context/i-db-context";
import { IRepository } from "./i-repository";
/**
 * BaseRepository<T>
 *
 * Repositorio genérico para operaciones CRUD sobre un objectStore de IndexedDB.
 *
 * Responsabilidades:
 * - Ejecutar operaciones usando la abstracción IDbContext (inyección por constructor).
 * - Gestionar la asignación de la clave generada por store.add / store.put al entity
 *   usando keyPath proporcionado en el constructor o inferido ('id' | '_id').
 *
 * Diseño:
 * - SRP: solo manipula un store concreto.
 * - DIP: depende de IDbContext (no de IDBDatabase directamente).
 * - OCP: métodos pueden ser usados/extendidos por repositorios específicos.
 *
 * Notas:
 * - La resolución/normalización de errores y la promisificación de IDBRequest la debe manejar IDbContext.
 *
 * @template T Tipo de la entidad almacenada en el objectStore.
 */
export default abstract class BaseRepository<T> implements IRepository<T> {
    protected dbContext: IDbContext;
    protected storeName: string;
    protected keyPath?: string;
    constructor(dbContext: IDbContext, storeName: string, keyPath?: string);
    /**
     * Crea una nueva entidad en el store.
     *
     * Comportamiento:
     * - Ejecuta store.add(entity) dentro de una transacción 'readwrite'.
     * - Si IndexedDB devuelve una clave (IDBValidKey), intenta asignarla a la entidad
     *   usando this.keyPath o inferiendo 'id'|'_id'.
     *
     * @param {T} entity Entidad a crear.
     * @returns {Promise<T>} La entidad creada (con clave asignada si aplica).
     * @throws Rechaza la promesa si la transacción o la request falla.
     */
    create(entity: T): Promise<T>;
    /**
     * Lee una entidad por su id.
     *
     * @param {IDBValidKey} id Clave primaria a buscar.
     * @returns {Promise<T|null>} La entidad encontrada o null si no existe.
     * @throws Rechaza la promesa si la transacción o la request falla.
     */
    read(id: IDBValidKey): Promise<T | null>;
    /**
     * Actualiza (o inserta) una entidad en el store.
     *
     * Comportamiento:
     * - Ejecuta store.put(entity) dentro de una transacción 'readwrite'.
     * - Si IndexedDB devuelve una clave (IDBValidKey), intenta asignarla a la entidad
     *   usando this.keyPath o inferido ('id'|'_id').
     *
     * @param {T} entity Entidad a actualizar.
     * @returns {Promise<T>} La entidad actualizada (con clave asignada si aplica).
     * @throws Rechaza la promesa si la transacción o la request falla.
     */
    update(entity: T): Promise<T>;
    /**
     * Elimina una entidad por su id.
     *
     * @param {IDBValidKey} id Clave primaria a eliminar.
     * @returns {Promise<void>}
     * @throws Rechaza la promesa si la transacción o la request falla.
     */
    delete(id: IDBValidKey): Promise<void>;
    /**
     * Obtiene todas las entidades del store.
     *
     * @returns {Promise<T[]>} Array con todas las entidades (vacío si no hay registros).
     * @throws Rechaza la promesa si la transacción o la request falla.
     */
    findAll(): Promise<T[]>;
}
