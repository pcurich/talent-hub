import { DBInitOptions, StoreConfig } from '../utils/inspect-db-structure';
export declare const FEEDBACK_STORE_CONFIG: StoreConfig;
export declare const FEEDBACK_DB_CONFIG: DBInitOptions;
