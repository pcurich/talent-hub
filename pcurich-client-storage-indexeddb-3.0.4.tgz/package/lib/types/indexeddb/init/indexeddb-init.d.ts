import { DbContext } from '../context/db-context';
import { DBInitOptions } from '../utils/inspect-db-structure';
/**
 * Obtiene la configuración real de la base de datos (metadata).
 */
export declare function getIndexedDbConfig(): Promise<DBInitOptions>;
/**
 * Crea la base de datos IndexedDB usando una configuración inicial o el valor por defecto.
 * @param cfg Configuración inicial opcional (DBInitOptions)
 * @returns Instancia de DbContext ya abierta
 */
export declare function createIndexedDbServices(cfg?: DBInitOptions): Promise<Record<string, any>>;
/**
 * Abre una base de datos IndexedDB existente sin ejecutar migraciones
 * @param cfg Configuración de la base de datos
 * @returns Instancia de DbContext ya abierta
 */
export declare function openExistingIndexedDb(cfg: DBInitOptions): Promise<DbContext>;
/**
 * Crea la base de datos IndexedDB usando una configuración inicial o el valor por defecto.
 * @param cfg Configuración inicial opcional (DBInitOptions)
 * @returns Instancia de DbContext ya abierta
 */
export declare function createDefaultIndexedDb(cfg?: DBInitOptions): Promise<DbContext>;
