import { DbContext } from '../context/db-context';
/**
 * Factory para crear instancias de servicios
 */
export type ServiceFactory = (ctx: DbContext, storeName: string, keyPath: any) => any;
/**
 * Registro de factories de servicios
 */
declare class ServiceRegistry {
    private factories;
    register(storeName: string, serviceName: string, factory: ServiceFactory): void;
    create(storeName: string, ctx: DbContext, keyPath: any): {
        serviceName: string;
        service: any;
    } | null;
    has(storeName: string): boolean;
}
/**
 * Registro global de servicios
 */
export declare const serviceRegistry: ServiceRegistry;
/**
 * Permite registrar nuevos servicios desde fuera del módulo
 */
export declare function registerService(storeName: string, serviceName: string, factory: ServiceFactory): void;
export {};
