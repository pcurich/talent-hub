import { DBInitOptions, StoreConfig } from '../utils/inspect-db-structure';
export declare const HTTP_MOCK_STORE_CONFIG: StoreConfig;
export declare const HTTP_MOCK_DB_CONFIG: DBInitOptions;
