import { DBInitOptions, StoreConfig } from '../utils/inspect-db-structure';
export declare const DUMMY_STORE_CONFIG: StoreConfig;
export declare const DUMMY_DB_CONFIG: DBInitOptions;
