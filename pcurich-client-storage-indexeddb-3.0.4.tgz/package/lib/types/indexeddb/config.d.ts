import { DBInitOptions } from './utils/inspect-db-structure';
export declare function setDbConfig(opts: DBInitOptions): void;
export declare function getDbConfig(): DBInitOptions;
export declare function isDbConfigInitialized(): boolean;
export declare function clearDbConfig(): void;
