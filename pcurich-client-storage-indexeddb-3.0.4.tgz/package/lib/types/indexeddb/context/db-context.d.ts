import { IDbContext } from "./i-db-context";
export type Migration = (db: IDBDatabase) => void;
export declare class DbContext implements IDbContext {
    private name;
    private version;
    private migrations;
    private dbPromise;
    private dbInstance;
    constructor(name: string, version?: number, migrations?: Migration[]);
    open(): Promise<IDBDatabase>;
    close(): Promise<void>;
    getDB(): Promise<IDBDatabase>;
    runTransaction<T>(storeName: string, mode: IDBTransactionMode, fn: (store: IDBObjectStore) => IDBRequest | Promise<any> | void): Promise<T>;
}
